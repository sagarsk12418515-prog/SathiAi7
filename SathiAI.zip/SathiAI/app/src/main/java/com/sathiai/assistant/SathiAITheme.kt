package com.sathiai.assistant
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val DarkColors = darkColorScheme(
    primary = Color(0xFF80CBC4), onPrimary = Color(0xFF00332E), background = Color(0xFF0E1513),
    surface = Color(0xFF0E1513), onBackground = Color(0xFFE0E3E1), onSurface = Color(0xFFE0E3E1)
)
@Composable fun SathiAITheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = DarkColors, content = content) }
