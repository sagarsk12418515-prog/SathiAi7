package com.sathiai.assistant.service
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
class SathiAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
